package bk;

import java.sql.Connection;
import java.sql.DriverManager;


/**
 *
 * @author 1BestCsharp
 */
public class MyConnection {
    
    
    // create a function to connect with mysql database
    public static void main(String args[]){
   
     
        Connection con = null;
        try {
            
            
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3307/db?serverTimezone=UTC", "root", "");
            System.out.println("h");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        
       
    }
    
}    

