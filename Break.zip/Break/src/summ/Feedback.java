
package summ;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.BevelBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;

import java.awt.Choice;

import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.JButton;
import javax.swing.JToggleButton;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.regex.Pattern;

import javax.swing.DropMode;

import java.awt.ComponentOrientation;

import javax.swing.JComboBox;

import summ.UserHome;

import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.TextArea;

import javax.swing.JTextArea;

import java.awt.Window.Type;
import java.awt.event.MouseMotionAdapter;

public class Feedback extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name;
	private JTextField id;
	private JTextField mail;
	int xmouse,ymouse;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Feedback frame = new Feedback();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Feedback() {
		setIgnoreRepaint(true);
		setUndecorated(true);
		setType(Type.POPUP);
		
		setBounds(100, 100, 543, 475);
		contentPane = new JPanel();
		contentPane.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(0, 0, 0), null, new Color(0, 0, 0), null));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, -14, 573, 53);
		panel.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x=e.getXOnScreen();
				int y=e.getYOnScreen();
				setLocation(x-xmouse,y-ymouse);
			}
		});
		panel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				xmouse=arg0.getXOnScreen();
				ymouse=arg0.getYOnScreen();
				
			}
		});
		contentPane.setLayout(null);
		panel.setBackground(SystemColor.textHighlight);
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(0, 0, 0), null, new Color(0, 0, 0), null));
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblFeedbackForm = new JLabel("Feedback Form");
		lblFeedbackForm.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblFeedbackForm.setBounds(230, 2, 156, 39);
		panel.add(lblFeedbackForm);
		
		JLabel lblEmployeename = new JLabel("EmployeeName");
		lblEmployeename.setBounds(129, 75, 107, 23);
		lblEmployeename.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblEmployeename);
		
		name = new JTextField();
		name.setBounds(259, 75, 168, 23);
		name.setFont(new Font("Tahoma",Font.PLAIN,14));
		contentPane.add(name);
		name.setColumns(10);
		
		JLabel lblEmployeeId = new JLabel("Employee id");
		lblEmployeeId.setBounds(149, 125, 87, 23);
		lblEmployeeId.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblEmployeeId);
		
		id = new JTextField();
		id.setBounds(259, 125, 168, 26);
		id.setFont(new Font("Tahoma",Font.PLAIN,14));
		contentPane.add(id);
		id.setColumns(10);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setBounds(172, 180, 64, 23);
		lblGender.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblGender);
		
		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setBounds(172, 231, 64, 23);
		lblEmail.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblEmail);
		
		mail = new JTextField();
		mail.setBounds(259, 231, 168, 25);
		mail.setFont(new Font("Tahoma",Font.PLAIN,14));
		contentPane.add(mail);
		mail.setColumns(10);
		JComboBox<String> com = new JComboBox();
		com.setBounds(259, 180, 168, 26);
		com.setBackground(SystemColor.controlHighlight);
		contentPane.add(com);
		com.addItem("-none-");
		com.addItem("Male");
		com.addItem("Female");
		com.addItem("Transgender");
		JLabel lblFeedback = new JLabel("Feedback");
		lblFeedback.setBounds(149, 297, 97, 39);
		lblFeedback.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblFeedback);
		JTextArea feed = new JTextArea();
		feed.setBounds(259, 297, 168, 61);
		feed.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(0, 0, 0), null, null, null));
		feed.setFont(new Font("Tahoma", Font.PLAIN, 14));
		feed.setFont(new Font("Tahoma",Font.PLAIN,14));
		contentPane.add(feed);
		
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.setBounds(237, 385, 97, 39);
		btnSubmit.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnSubmit.setBackground(new Color(0, 128, 0));
		btnSubmit.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent arg0) {
				  try {
					  
					  
		                Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/feedback?serverTimezone=UTC", "root", "");
		                String sql="insert into feed values (?, ?, ?, ?, ?)";
		                PreparedStatement pst=connection.prepareStatement(sql);
		                
		                
		                pst.setString(1,name.getText());
		                
		                pst.setString(2, id.getText());
		                String combo;
						  combo=com.getSelectedItem().toString();
						  com.setSelectedIndex(0);
		 pst.setString(3, combo);
		               pst.setString(4,mail.getText());
		               
		              
		               pst.setString(5,feed.getText());
		               pst.executeUpdate();
		               if(name.getText().trim().isEmpty()||id.getText().trim().isEmpty()||combo.startsWith("-none-")||mail.getText().trim().isEmpty()||feed.getText().trim().isEmpty())
						  {
							  JOptionPane.showMessageDialog(null, "All fields are required");
						  }
		                if(!Pattern.matches("^[a-zA-Z]+$", name.getText())){
		                	JOptionPane.showMessageDialog(null, "invalid name");	
		                }
		                if(!Pattern.matches("^[a-zA-Z0-9]+$", id.getText())){
		                	JOptionPane.showMessageDialog(null, "invalid employee id");	}
		                if(!Pattern.matches("^[a-zA-Z0-9]+[@]{1}+[a-zA-Z0-9]+[.]{1}+[a-zA-Z0-9]+$", mail.getText())){
		                	JOptionPane.showMessageDialog(null, "invalid email-id");	
		                }
						  else
						  {
		               JOptionPane.showMessageDialog(null, "feedback submitted");
		               dispose();
		                }}
		                
			
				  catch(Exception e)
				  {
					  System.out.println(e);
				  }
				  }
		});
		contentPane.add(btnSubmit);
		
		JButton btnNewButton = new JButton("Cancel");
		btnNewButton.setBounds(377, 385, 89, 39);
		btnNewButton.setBackground(new Color(255, 0, 51));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				dispose();
				
			}
		});
		contentPane.add(btnNewButton);
		
		
		
		
		
	}
}

