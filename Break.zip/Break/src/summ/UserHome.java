package summ;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UserHome extends JFrame {

	private JPanel contentPane;
	private static final long serialVersionUID = -943225114217328752L;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserHome frame = new UserHome(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param userName 
	 */
	public UserHome(String userName) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 604, 393);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnStartSession = new JButton("start session");
		btnStartSession.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnStartSession.setBounds(224, 111, 135, 34);
		contentPane.add(btnStartSession);
		
		JButton btnFeedback = new JButton("Feedback");
		btnFeedback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnFeedback.setBounds(29, 306, 89, 23);
		contentPane.add(btnFeedback);
		
		JButton btnLogout = new JButton("logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int a = JOptionPane.showConfirmDialog(btnLogout, "Are you sure?");
				if ( a== JOptionPane.YES_OPTION) {
				dispose();
                    UserLogin obj = new UserLogin();
                    obj.setTitle("User-Login");
                    obj.setVisible(true);
                }
				dispose();
                UserLogin obj = new UserLogin();
                obj.setTitle("User-Login");
                obj.setVisible(true);
			}
			
		});
		btnLogout.setBounds(478, 11, 89, 23);
		contentPane.add(btnLogout);
	}

}
