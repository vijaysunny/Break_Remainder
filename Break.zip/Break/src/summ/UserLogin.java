package summ;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;

public class UserLogin  extends JFrame{
	private static final long serialVersionUID = 3027592461125618335L;
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserLogin window = new UserLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserLogin() {
		

	/**
	 * Initialize the contents of the frame.
	 */



		frame = new JFrame();
		frame.setTitle("Break Reminder-Login");
		frame.setBounds(100, 100, 651, 384);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setBounds(285, 11, 177, 48);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 34));
		
		JLabel lblNewLabel_1 = new JLabel("UserName");
		lblNewLabel_1.setBounds(183, 84, 124, 43);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 24));
		
		JLabel lblNewLabel_2 = new JLabel("Employeeid");
		lblNewLabel_2.setBounds(183, 162, 132, 36);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 24));
		
		textField = new JTextField();
		textField.setBounds(317, 92, 145, 35);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(317, 161, 150, 36);
		textField_1.setColumns(10);
		
		JButton btnLogin = new JButton("login");
		btnLogin.setFont(new Font("Times New Roman", Font.BOLD, 24));
		btnLogin.setBounds(285, 223, 124, 36);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String UserName = textField.getText();
                String Employeeid = textField_1.getText();
                try {
                    Connection connection = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/db?serverTimezone=UTC", "root", "");

                    PreparedStatement st = (PreparedStatement) connection
                        .prepareStatement("Select UserName, Employeeid from login where UserName=? and Employeeid=?");

                    st.setString(1, UserName);
                    st.setString(2, Employeeid);
                    ResultSet rs = st.executeQuery();
                    if (rs.next()) {
                      dispose();
                        UserHome ah = new UserHome(UserName);
                        ah.setTitle("Welcome");
                        ah.setVisible(true);
                        JOptionPane.showMessageDialog(btnLogin, "You have successfully logged in");
                    } else {
                        JOptionPane.showMessageDialog(btnLogin, "Wrong Username & Employeeid");
                    }
                } catch (SQLException sqlException) {
                    sqlException.printStackTrace();
                }
            }

        });
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(lblNewLabel);
		frame.getContentPane().add(lblNewLabel_1);
		frame.getContentPane().add(lblNewLabel_2);
		frame.getContentPane().add(textField_1);
		frame.getContentPane().add(textField);
		frame.getContentPane().add(btnLogin);
		
		JButton btnNewButton = new JButton("Reset");
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 24));
		btnNewButton.setBounds(444, 223, 105, 36);
		frame.getContentPane().add(btnNewButton);
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
